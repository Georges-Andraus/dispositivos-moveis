package com.example.aula5_atv;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editNota1 = findViewById(R.id.editNota1);
        EditText editNota2 = findViewById(R.id.editNota2);
        Button buttonCalcularNota = findViewById(R.id.buttonCalcularNota);
        TextView textResultado = findViewById(R.id.textResultado);

        buttonCalcularNota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                double nota1 = Double.parseDouble(editNota1.getText().toString());
                double nota2 = Double.parseDouble(editNota2.getText().toString());

                double notaFinal = nota1 * 0.4 + nota2 * 0.6;

                String resultado = "A nota final do aluno foi: " + notaFinal;
                textResultado.setText(resultado);
            }
        });
    }
}

